package com.pharmacy.management.pharmacy_management_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmacyManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmacyManagementAppApplication.class, args);
	}

}
